﻿CREATE TABLE Sentences(
	s_string TEXT UNIQUE,
	s_id INTEGER NOT NULL PRIMARY KEY
);
CREATE TABLE Phenomena(
	p_string TEXT UNIQUE,
	p_id INTEGER NOT NULL PRIMARY KEY
);
CREATE TABLE Phenom2Sents(
	p_id INTEGER NOT NULL references Phenomena(p_id),
	s_id INTEGER NOT NULL references Sentences(s_id),
	UNIQUE (p_id,s_id)
);
CREATE TABLE Users(
	u_id INTEGER NOT NULL PRIMARY KEY,
	u_name TEXT UNIQUE);	
CREATE TABLE TMRs(
	tmr_id INTEGER NOT NULL PRIMARY KEY,
	tmr_string TEXT UNIQUE,
	s_id INTEGER NOT NULL references Sentences(s_id)
);
CREATE TABLE Runs(
	r_id INTEGER NOT NULL PRIMARY KEY,
	tmr_id INTEGER NOT NULL references TMRs(tmr_id),
	time_stamp REAL UNIQUE,
	num_runs INTEGER,
	u_id INTEGER,
	UNIQUE (tmr_id, time_stamp, u_id)
);
CREATE TABLE Tokens (
	to_id INTEGER NOT NULL PRIMARY KEY,
	to_string TEXT UNIQUE);
CREATE TABLE Senses (
	sen_id INTEGER NOT NULL PRIMARY KEY,
	sen_string TEXT UNIQUE);
CREATE TABLE Scopes (
	sco_id INTEGER NOT NULL PRIMARY KEY,
	sco_string TEXT UNIQUE);
CREATE TABLE Member_Types (
	memty_id INTEGER NOT NULL PRIMARY KEY,
	memty_string TEXT UNIQUE);
CREATE TABLE Concepts (
	con_id INTEGER NOT NULL PRIMARY KEY,
	con_string TEXT UNIQUE);
CREATE TABLE Attributed_Tos (
	att_to_id INTEGER NOT NULL PRIMARY KEY,
	att_to_string TEXT UNIQUE);
CREATE TABLE Components(
	c_id INTEGER NOT NULL PRIMARY KEY,
	tmr_id INTEGER NOT NULL REFERENCES TMRs(tmr_id),
	sco_id INTEGER REFERENCES Scopes(sco_id),
	to_id INTEGER REFERENCES Tokens(to_id),
	con_id INTEGER REFERENCES Concepts(con_id),
	sen_id INTEGER REFERENCES Senses(sen_id),
	att_to_id INTEGER REFERENCES Attributed_Tos(att_to_id),
	memty_id INTEGER REFERENCES Member_Types(memty_id),
	c_string TEXT NOT NULL UNIQUE
);