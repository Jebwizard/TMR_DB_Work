# Contains the methods to interface with SQLite via DBConnection

from tkinter import *
from tkinter import ttk
#import tk_MessageBox
import DBConnection



class SQLFunc:
    def __init__(self):
        print("What Database do you want to use?")
        #print("You can change this later.")
        input_var = input(" : ")
        print ("you entered " + input_var) 
        input_var = input_var + '.db'
        self.DataBase = DBConnection.DBConnection(input_var,'Stanford_Schema.sql')
        pass

    def connect_button(self,*args):
        self.error_not_coded()
        print("Not coded yet")
    
    def error_not_coded(self):
        root = Tk()
        root.title('ERROR')
        mainframe = ttk.Frame(root, padding="6 6 24 24")
        mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
        mainframe.columnconfigure(0, weight=1)
        mainframe.rowconfigure(0, weight=1)
        label = ttk.Label(mainframe, text='This is not coded yet')
        label.grid(column=0, row=0, sticky=(N, W, E, S))
        #tk_MessageBox.showerror('Error','This is not coded yet')

    def getPhenomOptions(self):
        return self.DataBase.getPhenomenon()

    def see_SentenceTable(self):
        text = self.DataBase.SentencesTableToString()
        root = Tk()
        root.title('Sentence Table')
        mainframe = ttk.Frame(root, padding="6 6 24 24")
        mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
        mainframe.columnconfigure(0, weight=1)
        mainframe.rowconfigure(0, weight=1)
        label = ttk.Label(mainframe, text=text)
        label.grid(column=0, row=0, sticky=(N, W, E, S))

    def see_PhenomenaTable(self):
        text = self.DataBase.PhenomenaTableToString()
        root = Tk()
        root.title('Phenonenon Table')
        mainframe = ttk.Frame(root, padding="6 6 24 24")
        mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
        mainframe.columnconfigure(0, weight=1)
        mainframe.rowconfigure(0, weight=1)
        label = ttk.Label(mainframe, text=text)
        label.grid(column=0, row=0, sticky=(N, W, E, S))

    def see_SentPhenomTable(self):
        text = self.DataBase.Phenom2SentsViewToString()
        root = Tk()
        root.title('Sentence/Phenonenon Relashionship Table')
        mainframe = ttk.Frame(root, padding="6 6 24 24")
        mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
        mainframe.columnconfigure(0, weight=1)
        mainframe.rowconfigure(0, weight=1)
        label = ttk.Label(mainframe, text=text)
        label.grid(column=0, row=0, sticky=(N, W, E, S))

    def see_TMRsTable(self):
        text = self.DataBase.TMRsTableToString()
        root = Tk()
        root.title('TMRs Table')
        mainframe = ttk.Frame(root, padding="6 6 24 24")
        mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
        mainframe.columnconfigure(0, weight=1)
        mainframe.rowconfigure(0, weight=1)
        label = ttk.Label(mainframe, text=text)
        label.grid(column=0, row=0, sticky=(N, W, E, S))

    def see_RunsTable(self):
        text = self.DataBase.RunsViewToString()
        root = Tk()
        root.title('Run View')
        mainframe = ttk.Frame(root, padding="6 6 24 24")
        mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
        mainframe.columnconfigure(0, weight=1)
        mainframe.rowconfigure(0, weight=1)
        label = ttk.Label(mainframe, text=text)
        label.grid(column=0, row=0, sticky=(N, W, E, S))

    def see_ComponentsTable(self):
        text = self.DataBase.ComponentsViewToString()
        root = Tk()
        root.title('Components Table')
        mainframe = ttk.Frame(root, padding="6 6 24 24")
        mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
        mainframe.columnconfigure(0, weight=1)
        mainframe.rowconfigure(0, weight=1)
        label = ttk.Label(mainframe, text=text)
        label.grid(column=0, row=0, sticky=(N, W, E, S))
       

    def addComponent(self, tmr_id, sco_string, to_string, con_string, mem_ty_string, sen_string, att_to_string, componentText):
        self.DataBase.addComponent(tmr_id, componentText, sco_string, to_string, con_string, sen_string, att_to_string, mem_ty_string)
        self.see_ComponentsTable()

    def addSentence(self,sentInput):
        self.DataBase.addSentence(sentInput)
        self.see_SentenceTable()

    def addPhenomena(self,phenomInput):
        self.DataBase.addPhenomena(phenomInput)
        self.see_PhenomenaTable()
    
    def addPhenomSent(self, sentInput, phenomInput):
        self.DataBase.addPhenomSent(sentInput,phenomInput)
        self.see_SentPhenomTable()

    def addRun(self, tmr_num, username, numRuns):
        self.DataBase.addRun(tmr_num,username,numRuns)
        self.see_RunsTable()
    
    def addTMR(self, tmr_text, sent_string):
        self.DataBase.addTMR(tmr_text,sent_string)
        self.see_TMRsTable()

    def findTMRsForSentence(self, sent_string):
        text = self.DataBase.FindTMRsForSentence(sent_string)
        root = Tk()
        root.title('TMRs that describe " {} "'.format(sent_string))
        mainframe = ttk.Frame(root, padding="6 6 24 24")
        mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
        mainframe.columnconfigure(0, weight=1)
        mainframe.rowconfigure(0, weight=1)
        label = ttk.Label(mainframe, text=text)
        label.grid(column=0, row=0, sticky=(N, W, E, S))

    def FindSentsForPhenom(self, phenom_string):
        text = self.DataBase.FindSentsForPhenom( phenom_string)
        root = Tk()
        root.title('Sentences that contain " {} "'.format(phenom_string))
        mainframe = ttk.Frame(root, padding="6 6 24 24")
        mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
        mainframe.columnconfigure(0, weight=1)
        mainframe.rowconfigure(0, weight=1)
        label = ttk.Label(mainframe, text=text)
        label.grid(column=0, row=0, sticky=(N, W, E, S))

    def FindPhenomForSent(self, sent_string):
        text = self.DataBase.FindPhenomForSent( sent_string)
        root = Tk()
        root.title('Phenomena that describe " {} "'.format(sent_string))
        mainframe = ttk.Frame(root, padding="6 6 24 24")
        mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
        mainframe.columnconfigure(0, weight=1)
        mainframe.rowconfigure(0, weight=1)
        label = ttk.Label(mainframe, text=text)
        label.grid(column=0, row=0, sticky=(N, W, E, S))

    def FindSentReadings(self):
        text = self.DataBase.FindSentReadings()
        root = Tk()
        root.title('Sentences with Multiple Readings')
        mainframe = ttk.Frame(root, padding="6 6 24 24")
        mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
        mainframe.columnconfigure(0, weight=1)
        mainframe.rowconfigure(0, weight=1)
        label = ttk.Label(mainframe, text=text)
        label.grid(column=0, row=0, sticky=(N, W, E, S))   