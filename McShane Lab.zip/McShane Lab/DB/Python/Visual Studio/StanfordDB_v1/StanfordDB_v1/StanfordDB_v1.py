# This is the GUI library
from tkinter import *
from tkinter import ttk
import SQLFunc
# This contains the logic to "talk" with SQL


SQLcontrol = SQLFunc.SQLFunc()


# Create the main window and the main frame
root = Tk()
root.title('Database Access')
# to add a custom icon:
# root.iconbitmap( pathname )
mainframe = ttk.Frame(root, padding="3 3 12 12")
mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
mainframe.columnconfigure(0, weight=1)
mainframe.rowconfigure(0, weight=1)


# Create the highest level Tabs to split apart the main types of operations
n = ttk.Notebook(mainframe)
n.grid(column=0, row=0, sticky=(N, W, E, S))

# Create and add the tabs of the highest types of operations
f1 = ttk.Frame(n)
f2 = ttk.Frame(n)
f3 = ttk.Frame(n)
n.add(f1, text='See Data')
n.add(f2, text='Add')
n.add(f3, text='Find')

# -----------------------------------------------------------------------
# Functions to run the Buttons

def see_SentenceTable():
    SQLcontrol.see_SentenceTable()
def see_PhenomenaTable():
    SQLcontrol.see_PhenomenaTable()
def see_SentPhenomTable():
    SQLcontrol.see_SentPhenomTable()
def see_TMRsTable():
    SQLcontrol.see_TMRsTable()
def see_RunsTable():
    SQLcontrol.see_RunsTable()
def see_ComponentsTable():
    SQLcontrol.see_ComponentsTable()

def submit_component():
    a = v_tmr.get()
    b = v_scope.get()
    c = v_token.get()
    d = v_concept.get()
    e = v_member_type.get()
    f = v_senses.get()
    g = v_attributed.get()
    h = v_fullText.get()
    if a == '':
        a = 'NULL'
    if b == '':
        b = 'NULL'
    if c == '':
        c = 'NULL'
    if d == '':
        d = 'NULL'
    if e == '':
        e = 'NULL'
    if f == '':
        f = 'NULL'
    if g == '':
        g = 'NULL'
    if h == '':
        h = 'NULL'
    SQLcontrol.addComponent(a,b,c,d,e,f,g,h)
    pass

def submit_sentence():
    SQLcontrol.addSentence(new_sentence.get())

def submit_phenomena():
    SQLcontrol.addPhenomena(new_phenomena.get())
    phenom_options = SQLcontrol.getPhenomOptions()

def submit_phenomSent():
    SQLcontrol.addPhenomSent(relat_sent.get(),relat_phenom_1.get())

def submit_Run():
    SQLcontrol.addRun(v_run_tmrID.get(),v_run_user.get(),v_run_num.get())

def submit_TMR():
    SQLcontrol.addTMR(tmr_text.get(),tmr_sentence.get())

def submit_findTMR4sent():
    SQLcontrol.findTMRsForSentence(find_1.get())

def submit_findSent4Phenom():
    SQLcontrol.FindSentsForPhenom(find_2.get())

def submit_findPhenom4Sent():
    SQLcontrol.FindPhenomForSent(find_3.get())

def submit_multipleRadings():
    SQLcontrol.FindSentReadings()

# -----------------------------------------------------------------------
# Widgets for the See Data Tab

b_seeSentences = ttk.Button(f1, text='Sentence Table', command=SQLcontrol.see_SentenceTable).grid(column=0,row=0, sticky=(N, S, E, W) )
b_seePhenomena = ttk.Button(f1, text='Phenomena Table', command=SQLcontrol.see_PhenomenaTable).grid(column=0,row=1, sticky=(N, S, E, W) )
b_seeSentPhenom = ttk.Button(f1, text='Sentence/Phenomena Table', command=SQLcontrol.see_SentPhenomTable).grid(column=0,row=2, sticky=(N, S, E, W) )
b_seeTMRs = ttk.Button(f1, text='TMR Table', command=SQLcontrol.see_TMRsTable).grid(column=0,row=3, sticky=(N, S, E, W) )
b_seeRuns = ttk.Button(f1, text='Runs Table', command=SQLcontrol.see_RunsTable).grid(column=0,row=4, sticky=(N, S, E, W) )
b_seeComponents = ttk.Button(f1, text='Components Table', command=SQLcontrol.see_ComponentsTable).grid(column=0,row=5, sticky=(N, S, E, W) )


# ------------------------------------------------------------------------
# Widgets for the Add Tab

label = ttk.Label(f2, text='Add the following element :').grid(column = 0, row = 0)

# Sub notebook to differentiate between the elements that are to be added
n_add = ttk.Notebook(f2)
n_add.grid(column=0, row=1, sticky=(N, W, E, S))

# Create and add the tabs of the types of elements that can be added
f_add1 = ttk.Frame(n_add)
f_add2 = ttk.Frame(n_add)
f_add3 = ttk.Frame(n_add)
f_add4 = ttk.Frame(n_add)
f_add5 = ttk.Frame(n_add)
f_add6 = ttk.Frame(n_add)

n_add.add(f_add5, text='Component')
n_add.add(f_add2, text='Phenomenon')
n_add.add(f_add4, text='Relationship')
n_add.add(f_add1, text='Sentence')
n_add.add(f_add6, text='Run')
n_add.add(f_add3, text='TMR')


# Widgets for the Add->Component tab
# frame = f_add5          
l_component_info = ttk.Label(f_add5, text='Leave blank if the component does not have a certain field').grid(
                                                                                                column=0,
                                                                                                row=0,
                                                                                                columnspan=2)
v_tmr = StringVar()
l_tmr = ttk.Label(f_add5, text='TMR ID : ').grid(column=0, row=1)
e_tmr = ttk.Entry(f_add5, textvariable=v_tmr, width = 100).grid(
                                                                column=1, row=1)
l_scope = ttk.Label(f_add5, text='SCOPE : ').grid(column=0, row=2)
v_scope = StringVar()
e_scope = ttk.Entry(f_add5, textvariable=v_scope, width = 100).grid(
                                                                column=1, row=2)
l_token = ttk.Label(f_add5, text='TOKEN : ').grid(column=0, row=3)
v_token = StringVar()
e_token = ttk.Entry(f_add5, textvariable=v_token, width = 100).grid(
                                                                column=1, row=3)
l_concept = ttk.Label(f_add5, text='CONCEPT : ').grid(column=0, row=4)
v_concept = StringVar()
e_concept = ttk.Entry(f_add5, textvariable=v_concept, width = 100).grid(
                                                                column=1, row=4)
l_member_type = ttk.Label(f_add5, text='MEMBER-TYPE : ').grid(column=0, row=5)
v_member_type = StringVar()
e_member_type = ttk.Entry(f_add5, textvariable=v_member_type, width = 100).grid(
                                                                column=1, row=5)
l_senses = ttk.Label(f_add5, text='FROM-SENSE : ').grid(column=0, row=6)
v_senses = StringVar()
e_senses = ttk.Entry(f_add5, textvariable=v_senses, width = 100).grid(
                                                                column=1, row=6)
l_attributed = ttk.Label(f_add5, text='ATTRIBUTED-TO : ').grid(column=0, row=7)
v_attributed = StringVar()
e_attributed = ttk.Entry(f_add5, textvariable=v_attributed, width = 100).grid(
                                                                column=1, row=7)
l_fullText = ttk.Label(f_add5, text='Component Text : ').grid(column=0, row=8)
v_fullText = StringVar()
e_fullText = ttk.Entry(f_add5, textvariable=v_fullText, width = 100).grid(
                                                                column=1, row=8)
b_add_component = ttk.Button(f_add5, text='Submit', command=submit_component).grid(
                                                                                column=1,
                                                                                row=9)


# Widgets for the Add->Sentence tab
l_new_sent = ttk.Label(f_add1, text='Sentence :').grid(column=0, row = 0)
new_sentence = StringVar()
e_add_sentence = ttk.Entry(f_add1,textvariable=new_sentence, width = 100).grid(
                                                            column=1,
                                                            row=0,
                                                            sticky = (E,W))
b_add_sent = ttk.Button(f_add1, text='Submit', command=submit_sentence).grid(
                                                                             column=1,
                                                                             row=1)

# Widgets for the Add->Phenomena tab
l_new_phenom = ttk.Label(f_add2, text='Phenomenon :').grid(column=0, row = 0)
new_phenomena = StringVar()
e_add_phenomena = ttk.Entry(f_add2,textvariable=new_phenomena, width = 100).grid(
                                                            column=1,
                                                            row=0,
                                                            sticky = (E,W))
e_add_phenom = ttk.Button(f_add2, text='Submit', command=submit_phenomena).grid(
                                                                            column=1,
                                                                            row=1)
# Widgets for the Add->TMR tab

# Labels
l_sentence = ttk.Label(f_add3, text='Senetnece :').grid(column = 0, row = 0)
l_TMR = ttk.Label(f_add3, text='TMR Text:').grid(column = 0, row = 2)

# Variables
tmr_sentence = StringVar()
tmr_text = StringVar()

# Text entry widgets
e_tmr_sent = ttk.Entry(f_add3, textvariable=tmr_sentence, width = 100).grid(column=1,row=0)
e_tmr_tmr = ttk.Entry(f_add3, textvariable=tmr_text , width=100 ).grid(column=1,row=2)

# Button to submit responces
b_add_run = ttk.Button(f_add3, text='Submit', command=submit_TMR).grid(
                                                                       column=1,
                                                                       row=4)

# Widgets for the Add-> Run tab
# f_add6

# Labels
l_run_tmrID = ttk.Label(f_add6, text = 'TMR ID : ').grid(column = 0, row = 0)
l_run_num = ttk.Label(f_add6, text = 'Number of Runs : ').grid(column = 0, row = 1)
l_run_user = ttk.Label(f_add6, text = 'User : ').grid(column = 0, row = 2)

# Variables
v_run_tmrID = IntVar()
v_run_num = IntVar()
v_run_user = StringVar()

# Entries (text fields)
e_run_tmrID = ttk.Entry(f_add6, textvariable=v_run_tmrID, width = 10).grid(column = 1, row = 0)
e_run_num = ttk.Entry(f_add6, textvariable=v_run_num, width = 10).grid(column = 1, row = 1)
e_run_user = ttk.Entry(f_add6, textvariable=v_run_user, width = 20).grid(column = 1, row = 2)

# Button
b_run_submit = ttk.Button(f_add6, text = 'Submit', command = submit_Run).grid(column = 1, row = 3)

# Widegets for the Add-> Relationships tab
# f_add4

phenom_options = SQLcontrol.getPhenomOptions()

l_top = ttk.Label(f_add4, text='Connect a Sentnece to a Phenomenon').grid(column=0,
                                                                            row=0)
relat_sent = StringVar()
relat_phenom_1 = StringVar()
relat_phenom_1.set(phenom_options[1])

l_relate_sent = ttk.Label(f_add4, text='Sentence:').grid(column=0,row=1)
e_relate_sent = ttk.Entry(f_add4, textvariable=relat_sent, width = 100).grid(
                                                                column=1,
                                                                row=1)
l_relate_phenom = ttk.Label(f_add4, text='Phenomena:').grid(column=0,row=2)
#e_relate_phenom = ttk.Entry(f_add4, textvariable=relat_phenom_1, width = 100).grid(
#                                                                column=1,
#                                                                row=2)
d_phenom_dropdown_1 = ttk.OptionMenu(f_add4, relat_phenom_1, *phenom_options).grid(
                                                                    column=1,
                                                                    row=2)

b_sent_relat = ttk.Button(f_add4, text='Submit', command=submit_phenomSent).grid(
                                                                            column = 1,
                                                                            row = 3)



# not working
# seperator = ttk.Separator(f_add4, orient = HORIZONTAL).grid(row=4)

## Code for a way to say a TMR has a certain phenomena
#label_bottom = ttk.Label(f_add4, text='Connect a TMR to a Phenomenon').grid(column=0,
#                                                                          row=5)
#relat_tmr = StringVar()
#relat_phenom_2 = StringVar()
#relat_phenom_2.set(phenom_options[1])

#l_relate_tmr = ttk.Label(f_add4, text='TMR ID:').grid(column=0,row=6)
#e_relate_tmr= ttk.Entry(f_add4, textvariable=relat_tmr, width = 100).grid(
#                                                                column=1,
#                                                                row=6)
#l_relate_phenom = ttk.Label(f_add4, text='Phenomenon:').grid(column=0,row=7)
##e_relate_phenom = ttk.Entry(f_add4, textvariable=relat_phenom_2, width = 100).grid(
##                                                                column=1,
##                                                                row=7)
#d_phenom_dropdown_2 = ttk.OptionMenu(f_add4, relat_phenom_2, *phenom_options).grid(
#                                                                    column=1,
#                                                                    row=7)


#b_tmr_relat = ttk.Button(f_add4, text='Submit', command=SQLcontrol.connect_button).grid(
#                                                                            column = 1,
#                                                                            row = 8)

# Already part of Add-> TMR run
# Widgets for Add-> User Tab
#l_user = ttk.Label(f_add6, text='User Name : ').grid(column=0, row=0)
#v_user = StringVar()
#e_user = ttk.Entry(f_add6, textvariable=v_attributed, width = 100).grid(
#                                                                column=1, row=0)
#b_add_component = ttk.Button(f_add6, text='Submit', command=SQLFunc.connect_button).grid(
#                                                                                column=1,
#                                                                                row=1)


# --------------------------------------------------------------------------------
# Widgets for the Find tab
# frame : f3

find_1 = StringVar()
l_find_1 = ttk.Label(f3,text='What TMRs describe the following sentence?').grid(
                                                                            column=0,
                                                                            row=0)
e_find_1 = ttk.Entry(f3, textvariable = find_1, width = 100).grid(
                                                                column=0,
                                                                row=1)
b_find_1 = ttk.Button(f3, text='Submit', command=submit_findTMR4sent).grid(
                                                                        column=0,
                                                                        row=2)

find_2 = StringVar()
l_find_2 = ttk.Label(f3,text='What sentences conatin the following phenomenon?').grid(
                                                                            column=0,
                                                                            row=3)
e_find_2 = ttk.Entry(f3, textvariable = find_2, width = 100).grid(
                                                                column=0,
                                                                row=4)
b_find_2 = ttk.Button(f3, text='Submit', command=submit_findSent4Phenom).grid(
                                                                        column=0,
                                                                        row=5)

find_3 = StringVar()
l_find_3 = ttk.Label(f3,text='What phenomena are in the following sentence?').grid(
                                                                            column=0,
                                                                            row=6)
e_find_3 = ttk.Entry(f3, textvariable = find_3, width = 100).grid(
                                                                column=0,
                                                                row=7)
b_find_3 = ttk.Button(f3, text='Submit', command=submit_findPhenom4Sent).grid(
                                                                        column=0,
                                                                        row=8)

l_find_4 = ttk.Label(f3,text='What sentences have mulitple readings?').grid(
                                                                            column=0,
                                                                            row=9)
b_find_4 = ttk.Button(f3, text='Submit', command=submit_multipleRadings).grid(
                                                                        column=0,
                                                                        row=10)


# This catches the closing to the main window to ensure
# that the connection to the server is cut off

def on_closing():
    print("I am closing!")
    #if connected is True:
    #    connection.close()
    root.destroy()

root.protocol("WM_DELETE_WINDOW",on_closing)

# Command to run the application in a loop till terminated by the  user
root.mainloop()