import os
import sys
import sqlite3
import datetime

class DBConnection(object):
    
    ## Called when a DBConnection Object is created.
    ## Sets up the Schema of the Database
    def __init__(self, filename , schema_file ):
        self.db_filename = filename
        self.schema_filename = schema_file
        self.db_is_new = not os.path.exists(self.db_filename)
        with sqlite3.connect(self.db_filename) as conn:
            if self.db_is_new:
                print ('New Database. Creating schema')
                with open(self.schema_filename, 'rt') as f:
                    schema = f.read()
                    schema = schema[3:]
                conn.executescript(schema)
                SentPhenom_view = """
                            CREATE VIEW v_SentPhenom
                            AS
                            SELECT Phenomena.p_string, Sentences.s_string
                            FROM Phenom2Sents
	                            INNER JOIN Sentences
		                            ON Sentences.s_id = Phenom2Sents.s_id
	                            INNER JOIN Phenomena
		                            ON Phenomena.p_id = Phenom2Sents.p_id
                            """
                conn.execute(SentPhenom_view)
                conn.commit()
                Runs_view = """
                            CREATE VIEW v_Runs
                            AS
                            SELECT Runs.r_ID, Sentences.s_string, Runs.tmr_id, Runs.time_stamp, Users.u_name 
                            FROM Runs
	                            INNER JOIN Users
		                            ON Runs.u_id = Users.u_id
	                            INNER JOIN TMRs
		                            ON Runs.tmr_id = TMRs.tmr_id
                                INNER JOIN Sentences
                                    ON TMRs.s_id = Sentences.s_id
                            """
                conn.execute(Runs_view)
                conn.commit()
                Componenets_view = """
                            CREATE VIEW v_Components
                            AS
                            SELECT Components.c_id, Components.tmr_id, Scopes.sco_string, Tokens.to_string,
                                   Concepts.con_string, Senses.sen_string, Attributed_Tos.att_to_string,
                                   Member_Types.memty_string, Components.c_string
                            FROM Components
	                            LEFT OUTER JOIN Scopes
		                            ON Components.sco_id = Scopes.sco_id
                                LEFT OUTER JOIN Tokens
                                    ON Components.to_id = Tokens.to_id
                                LEFT OUTER JOIN Concepts
                                   ON Components.con_id = Concepts.con_id
                               LEFT OUTER JOIN Senses
                                   ON Components.sen_id = Senses.sen_id
                               LEFT OUTER JOIN Attributed_Tos
                                   ON Components.att_to_id = Attributed_Tos.att_to_id
	                           LEFT OUTER JOIN Member_Types
		                           ON Components.memty_id = Member_Types.memty_id
                            """
                conn.execute(Componenets_view)
                conn.commit() 
                self.popPhenomena()
                conn.commit()           
            else:
                print ('Database exists, assume schema does, too.')

    ## Passes SQL strings to the curser to be run
    ## WARNING!!! THIS CAN ALLOW SQL INSERTION ATTACKS
    def execute(self, input_sql , set):
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute( input_sql, set )
            conn.commit()
    
    ## Adds a Sentence to the Database
    ## requires the Schema to have a Sentences Table
    ## Does not insert duplicate rows
    ## Returns the ID of the input
    def addSentence(self,input):
        temp = None
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            s = '' + str(input)
            cursor.execute( """
                            INSERT OR IGNORE INTO Sentences (s_string)
                            VALUES (?)
                            """, [s] )
            conn.commit()
            cursor.execute("""
                            select * from Sentences
                            """)
            for row in cursor.fetchall():
                s_string, s_id = row
                if s_string == input:
                    temp = s_id
                    return temp
            return temp

    ## Prints the Sentences Table
    ## requires the Schema to have a Sentences Table
    def SentencesTable(self):
        print('-------------------------------------')
        print('Sentences Table')
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from Sentences
                            """)
            for row in cursor.fetchall():
                s_id, s_string = row
                print( '{} | {}'.format(s_id,s_string) )

    ## The Sentences Table to_string function
    ## requires the Schema to have a Sentences Table
    def SentencesTableToString(self):
        temp = '-------------------------------------\n'
        temp = temp + 'Sentences Table\n'
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from Sentences
                            """)
            for row in cursor.fetchall():
                s_id, s_string = row
                temp_row = '{} | {} \n'.format(s_string,s_id)
                temp = temp + temp_row
        return temp

    ## Adds a Phenomena to the Database
    ## requires the Schema to have a Phenomena Table
    ## Does not insert duplicate rows
    ## Returns the ID of the input
    def addPhenomena(self,input):
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            p = (input, )
            cursor.execute("""
                            INSERT OR IGNORE INTO Phenomena (p_string)
                            VALUES (?)
                            """, p)
            conn.commit()
            cursor.execute("""
                            select * from Phenomena
                            """)
            for row in cursor.fetchall():
                p_string, p_id = row
                if p_string == input:
                    temp = p_id
                    return temp

    ## populates the Phenomena table with default values
    def popPhenomena(self):
        data = ['personal pronoun','demonstrative pronoun',
                'BRE-NP','NP-def','NP-indef','VP ellipsis','I',
                'you','he','she','it','they','we','intransitive',
                'transitive','ditransitive','xcomp','comp','plus-PP',
                'plus-PP-opt','relative clause','passive','question',
                'command','dialog fragment','non-dialog fragment',
                'modality','set','aspect','indirect speech act','implicature']
        for i in data:
            self.addPhenomena(i)  
        pass    

    ## Returns a list of Phenomena
    def getPhenomenon(self):
        with sqlite3.connect(self.db_filename) as conn:
            temp = ['']
            cursor = conn.cursor()
            cursor.execute("""
                            select * from Phenomena
                            """)
            for row in cursor.fetchall():
                p_string, p_id = row
                temp.append(p_string)
            return temp

    ## Prints the Phenomena Table
    ## requires the Schema to have a Phenomena Table
    def PhenomenaTable(self):
        print('-------------------------------------')
        print('Phenomena Table')
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from Phenomena
                            """)
            for row in cursor.fetchall():
                p_id, p_string = row
                print( '{} | {}'.format(p_id,p_string) )

    def PhenomenaTableToString(self):
        temp = '-------------------------------------\n'
        temp = temp + 'Phenomena Table\n'
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from Phenomena
                            """)
            for row in cursor.fetchall():
                p_id, p_string = row
                temp_row = '{} | {} \n'.format(p_string,p_id)
                temp = temp + temp_row   
        return temp     
        
    ## Adds a Phenomena-Sentence Relationship to the Database
    ## requires the Schema to have a Phenom2Sents Table
    ## Does not insert duplicate rows
    def addPhenomSent(self,s_str, p_str):
        phenomID = self.addPhenomena(p_str)
        sentID = self.addSentence(s_str)
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()                
            ## Using phenomId and sentID, add a record to table            
            i = (phenomID, sentID, )
            cursor.execute("""
                            INSERT OR IGNORE INTO Phenom2Sents (p_id, s_id)
                            VALUES (?,?)
                            """, i )

    ## Prints the Phenom2Sents Table
    ## requires the Schema to have a Phenom2Sents Table
    def Phenom2SentsTable(self):
        print('-------------------------------------')
        print('Phenomena/ Sentence Relationship table')
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from Phenom2Sents
                            """)
            for row in cursor.fetchall():
                p_id, s_id = row
                print( '{} | {}'.format(p_id,s_id) )

    ## Prints the Phenom2Sents View
    ## requires the Schema to have a Phenom2Sents View
    def Phenom2SentsView(self):
        print('-------------------------------------')
        print('Phenomena/ Sentence Relationship View')
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from v_SentPhenom
                            """)
            for row in cursor.fetchall():
                s_string, p_string = row
                print( '{} | {}'.format(s_string,p_string) ) 
    
    ## Phenom2Sents View To String
    ## requires the Schema to have a Phenom2Sents View
    def Phenom2SentsViewToString(self):
        temp = '-------------------------------------\n'
        temp = temp + 'Phenomena/ Sentence Relationship View\n'
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from v_SentPhenom
                            """)
            for row in cursor.fetchall():
                s_string, p_string = row
                temp_row = '{} | {}\n'.format(s_string,p_string)
                temp = temp + temp_row
            return temp    

## USERS u_id, u_name
    ## Adds a User to the Database
    ## requires the Schema to have a Users Table
    ## Does not insert duplicate rows
    ## Returns the ID of the input
    def addUser(self,input):
        temp = None
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            s = (input,)
            cursor.execute( """
                            INSERT OR IGNORE INTO Users (u_name)
                            VALUES (?)
                            """, s )
            conn.commit()
            cursor.execute("""
                            select * from Users
                            """)
            for row in cursor.fetchall():
                u_id, u_name = row
                if u_name == input:
                    temp = u_id
                    return temp
            return temp

    ## Prints the Users Table
    ## requires the Schema to have a Users Table
    def UsersTable(self):
        print('-------------------------------------')
        print('Users Table')
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from Users
                            """)
            for row in cursor.fetchall():
                u_id, u_name = row
                print( '{} | {}'.format(u_id,u_name) )

## TMRs tmr_id, tmr_string, s_id
    ## Adds a TMR to the Database
    ## requires the Schema to have a TMRs Table
    ## Does not insert duplicate rows
    ## TODO: Test to ensure that it returns the correct row number
    def addTMR(self,TMR_input, s_str):
        sentID = self.addSentence(s_str)
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()                
            ## Using TMR_input and sentID, add a record to table            
            i = (TMR_input, sentID, )
            cursor.execute("""
                            INSERT OR IGNORE INTO TMRs (tmr_string, s_id)
                            VALUES (?,?)
                            """, i )
            conn.commit()
            ## Find and return the correct row number
            cursor.execute("""
                            select * from TMRs
                            """)
            for row in cursor.fetchall():
                tmr_id, tmr_string, s_id = row
                if tmr_string == TMR_input:
                    temp = tmr_id
                    return temp
        return None

    ## Prints the TMRs Table
    ## requires the Schema to have a TMRs Table
    def TMRsTable(self):
        print('-------------------------------------')
        print('TMRs table')
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from TMRs
                            """)
            for row in cursor.fetchall():
                tmr_id, tmr_string, s_id = row
                tmr_string = tmr_string[:25]
                print( '{} | {} | {}'.format(tmr_id, tmr_string, s_id ) )

    ## TMRs Table To String
    ## requires the Schema to have a TMRs Table
    def TMRsTableToString(self):
        temp = '-------------------------------------\n'
        temp = temp + 'TMRs table\n'
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from TMRs
                            """)
            for row in cursor.fetchall():
                tmr_id, tmr_string, s_id = row
                tmr_string = tmr_string[:25]
                temp_row = '{} | {} | {}\n'.format(tmr_id, tmr_string, s_id )
                temp = temp + temp_row
            return temp


## Runs r_id, tmr_id, time_stamp, u_id
    ## Adds a Run to the Database
    ## requires the Schema to have a Runs Table
    ## Does not insert duplicate rows
    def addRun(self, tmr_id, user_name, num_runs ):
        userID = self.addUser(user_name)
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()                
            ## Using UserId and tmr_id, add a record to table            
            now = datetime.datetime.now()
            epoch = datetime.datetime.utcfromtimestamp(0)
            delta = now - epoch
            time_stamp = delta.total_seconds()
            print('tmr_id : {}'.format(tmr_id))
            i = (tmr_id, time_stamp , userID, num_runs )
            cursor.execute("""
                            INSERT OR IGNORE INTO Runs (tmr_id, time_stamp, u_id, num_runs)
                            VALUES (?,?,?,?)
                            """, i )
            conn.commit()

    ## Prints the Runs Table
    ## requires the Schema to have a Runs Table
    def RunsTable(self):
        print('-------------------------------------')
        print('Runs table')
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from Runs
                            """)
            for row in cursor.fetchall():
                r_id, tmr_id, time_stamp, u_id = row
                tempTime = datetime.datetime.utcfromtimestamp(time_stamp)
                print( '{} | {} | {} | {}'.format(r_id, tmr_id, tempTime, u_id ) )

    ## Prints v_Runs
    ## Requires that the schema has a v_Runs view
    def RunsView(self):
        print('-------------------------------------')
        print('Runs View')
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from v_Runs
                            """)
            for row in cursor.fetchall():
                r_id, s_string , tmr_id, time_stamp, u_name = row
                tempTime = datetime.datetime.utcfromtimestamp(time_stamp)
                print( '{} | {} | {} | {} | {}'.format(r_id, s_string , tmr_id, time_stamp, u_name ) )

    ## v_RunsToString
    ## Require that hte schema has a v_Runs view
    def RunsViewToString(self):
        temp = '-------------------------------------\n'
        temp = temp + 'Runs View\n'
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from v_Runs
                            """)
            for row in cursor.fetchall():
                r_id, s_string , tmr_id, time_stamp, u_name = row
                tempTime = datetime.datetime.utcfromtimestamp(time_stamp)
                temp_row = '{} | {} | {} | {} | {}\n'.format(r_id, s_string , tmr_id, time_stamp, u_name )
                temp  = temp + temp_row
            return temp

## Tokens to_id, to_string
    ## Adds a Token to the Database
    ## requires the Schema to have a Tokens Table
    ## Does not insert duplicate rows
    ## Returns the ID of the input
    def addToken(self,input):
        temp = None
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            s = (input,)
            cursor.execute( """
                            INSERT OR IGNORE INTO Tokens (to_string)
                            VALUES (?)
                            """, s )
            conn.commit()
            cursor.execute("""
                            select * from Tokens
                            """)
            for row in cursor.fetchall():
                to_id, to_string = row
                if to_string == input:
                    temp = to_id
                    return temp
            return temp

    ## Prints the Users Table
    ## requires the Schema to have a Users Table
    def TokensTable(self):
        print('-------------------------------------')
        print('Tokens Table')
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from Tokens
                            """)
            for row in cursor.fetchall():
                to_id, to_string = row
                print( '{} | {}'.format(to_id, to_string) )

## Senses sen_id, sen_string
    ## Adds a Sense to the Database
    ## requires the Schema to have a Senese Table
    ## Does not insert duplicate rows
    ## Returns the ID of the input
    def addSense(self,input):
        temp = None
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            s = (input,)
            cursor.execute( """
                            INSERT OR IGNORE INTO Senses (sen_string)
                            VALUES (?)
                            """, s )
            conn.commit()
            cursor.execute("""
                            select * from Senses
                            """)
            for row in cursor.fetchall():
                sen_id, sen_string = row
                if sen_string == input:
                    temp = sen_id
                    return temp
            return temp

    ## Prints the Senses Table
    ## requires the Schema to have a Senses Table
    def SensesTable(self):
        print('-------------------------------------')
        print('Senses Table')
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from Senses
                            """)
            for row in cursor.fetchall():
                sen_id, sen_string = row
                print( '{} | {}'.format(sen_id, sen_string) )


## Scopes sco_id, sco_string
    ## Adds a Scope to the Database
    ## requires the Schema to have a Scope Table
    ## Does not insert duplicate rows
    ## Returns the ID of the input
    def addScope(self,input):
        temp = None
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            s = (input,)
            cursor.execute( """
                            INSERT OR IGNORE INTO Scopes (sco_string)
                            VALUES (?)
                            """, s )
            conn.commit()
            cursor.execute("""
                            select * from Scopes
                            """)
            for row in cursor.fetchall():
                sco_id, sco_string = row
                if sco_string == input:
                    temp = sco_id
                    return temp
            return temp

    ## Prints the Scopes Table
    ## requires the Schema to have a Scopes Table
    def ScopesTable(self):
        print('-------------------------------------')
        print('Scopes Table')
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from Scopes
                            """)
            for row in cursor.fetchall():
                sco_id, sco_string = row
                print( '{} | {}'.format(sco_id, sco_string ) )


## Member_Types memty_id, memty_string
    ## Adds a Member_Type to the Database
    ## requires the Schema to have a Member_Types Table
    ## Does not insert duplicate rows
    ## Returns the ID of the input
    def addMember_Type(self,input):
        temp = None
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            s = (input,)
            cursor.execute( """
                            INSERT OR IGNORE INTO Member_Types (memty_string)
                            VALUES (?)
                            """, s )
            conn.commit()
            cursor.execute("""
                            select * from Member_Types
                            """)
            for row in cursor.fetchall():
                memty_id, memty_string = row
                if memty_string == input:
                    temp = memty_id
                    return temp
            return temp

    ## Prints the Member_Types Table
    ## requires the Schema to have a Member_Types Table
    def Member_TypesTable(self):
        print('-------------------------------------')
        print('Member_Types Table')
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from Member_Types
                            """)
            for row in cursor.fetchall():
                memty_id, memty_string = row
                print( '{} | {}'.format(memty_id, memty_string )  )


## Concepts con_id, con_string
    ## Adds a Concept to the Database
    ## requires the Schema to have a Concepts Table
    ## Does not insert duplicate rows
    ## Returns the ID of the input
    def addConcept(self,input):
        temp = None
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            s = (input,)
            cursor.execute( """
                            INSERT OR IGNORE INTO Concepts (con_string)
                            VALUES (?)
                            """, s )
            conn.commit()
            cursor.execute("""
                            select * from Concepts
                            """)
            for row in cursor.fetchall():
                con_id, con_string = row
                if con_string == input:
                    temp = con_id
                    return temp
            return temp

    ## Prints the Concepts Table
    ## requires the Schema to have a Concepts Table
    def ConceptsTable(self):
        print('-------------------------------------')
        print('Concepts Table')
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from Concepts
                            """)
            for row in cursor.fetchall():
                con_id, con_string = row
                print( '{} | {}'.format(con_id, con_string )  )


## Attributed_Tos att_to_id, att_to_string
    ## Adds a Attributed_To to the Database
    ## requires the Schema to have a Attributed_Tos Table
    ## Does not insert duplicate rows
    ## Returns the ID of the input
    def addAttributed_To(self,input):
        temp = None
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            s = (input,)
            cursor.execute( """
                            INSERT OR IGNORE INTO Attributed_Tos (att_to_string)
                            VALUES (?)
                            """, s )
            conn.commit()
            cursor.execute("""
                            select * from Attributed_Tos
                            """)
            for row in cursor.fetchall():
                att_to_id, att_to_string = row
                if att_to_string == input:
                    temp = att_to_id
                    return temp
            return temp

    ## Prints the Attributed_Tos Table
    ## requires the Schema to have a Attributed_Tos Table
    def Attributed_TosTable(self):
        print('-------------------------------------')
        print('Attributed_Tos Table')
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from Attributed_Tos
                            """)
            for row in cursor.fetchall():
                att_to_id, att_to_string = row
                print( '{} | {}'.format(att_to_id, att_to_string )  )


## Components c_id, tmr_id, sco_id, to_id, con_id, sen_id, att_to_id, memty_id, c_string
    ## Adds a Components to the Database
    ## requires the Schema to have a Components Table
    ## Does not insert duplicate rows
    def addComponent(self, tmr_id, componentString , scope = None, token = None, concept = None, sense = None,  attributedTo = None, memberType = None ):
        # Scope ID
        if scope is None:
            scopeID = 'NULL'
        else:
            scopeID = self.addScope(scope)
        # Token ID
        if token is None:
            tokenID = 'NULL'
        else:
            tokenID = self.addToken(token)
        # Concept ID
        if concept is None:
            conceptID = 'NULL'
        else:
            conceptID = self.addConcept(concept)
        # Sense ID
        if sense is None:
            senseID = 'NULL'
        else:
            senseID = self.addSense(sense)
        # Attributed_To ID
        if attributedTo is None:
            attributedToID = 'NULL'
        else:
            attributedToID = self.addAttributed_To(attributedTo)
        # Member Type ID
        if memberType is None:
            memberTypeID = 'NULL'
        else:
            memberTypeID = self.addMember_Type(memberType)
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()                
            ## Using the varibales, add a record to table            
            i = (tmr_id, scopeID, tokenID, conceptID, senseID, attributedToID, memberTypeID, componentString,  )
            cursor.execute("""
                            INSERT OR IGNORE INTO Components (tmr_id, sco_id, to_id, con_id, sen_id, att_to_id, memty_id, c_string)
                            VALUES (?,?,?,?,?,?,?,?)
                            """, i )
            conn.commit()

    ## Prints the Components Table
    ## requires the Schema to have a Components Table
    def ComponentsTable(self):
        print('-------------------------------------')
        print('Components table')
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from Components
                            """)
            for row in cursor.fetchall():
                print(len(row))
                c_id, tmr_id, sco_id, to_id, con_id, sen_id, att_to_id, memty_id, c_string = row
                c_string = c_string[:15]
                print( '{} | {} | {} | {} | {} | {} | {} | {} | {}'
                        .format(c_id, tmr_id, sco_id, to_id, con_id, sen_id, att_to_id, memty_id, c_string ) )

    ## Prints v_Components
    ## Requires that the schema has a v_Components view
    def ComponentsView(self):
        print('-------------------------------------')
        print('Components View')
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from v_Components
                            """)
            for row in cursor.fetchall():
                c_id, tmr_id, sco_string, to_string, con_string, sen_string, att_to_string, memty_string, c_string = row
                print( '{} | {} | {} | {} | {} | {} | {} | {} | {}'.format(c_id, tmr_id, sco_string, to_string, con_string, sen_string, att_to_string, memty_string, c_string ) )

    ## v_ComponentsToString
    ## Requires that the schema has a v_Components view
    def ComponentsViewToString(self):
        temp = '-------------------------------------\n'
        temp = temp + 'Components View\n'
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select * from v_Components
                            ORDER BY tmr_id
                            """)
            for row in cursor.fetchall():
                c_id, tmr_id, sco_string, to_string, con_string, sen_string, att_to_string, memty_string, c_string = row
                c_string = c_string[:50]
                temp_row = '{} | {} | {} | {} | {} | {} | {} | {} | {}\n'.format(c_id, tmr_id, sco_string, to_string, con_string, sen_string, att_to_string, memty_string, c_string ) 
                temp = temp + temp_row
            return temp

    ## Return TMRs that match a certain sentence
    def FindTMRsForSentence(self, sent_string):
        temp = '-------------------------------------\n'
        temp = temp + 'TMRs that describe " {} " \n'.format(sent_string)
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select TMRs.tmr_id, TMRs.tmr_string, Sentences.s_string from TMRs 
                            INNER JOIN Sentences
                                ON Sentences.s_id = TMRs.s_id
                            WHERE Sentences.s_string = '{}'
                            """.format(sent_string))
            for row in cursor.fetchall():
                tmr_id, tmr_string, s_string = row
                tmr_string = tmr_string[:50]
                temp_row = '{} | {}\n'.format( tmr_id, tmr_string ) 
                temp = temp + temp_row
            return temp

    ## Return Sentences that have a certain Phenomena
    def FindSentsForPhenom(self, phenom_string):
        temp = '-------------------------------------\n'
        temp = temp + 'Sentences that contain " {} " \n'.format(phenom_string)
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select Sentences.s_string, Sentences.s_id from Phenom2Sents 
                            INNER JOIN Phenomena
                                ON Phenomena.p_id = Phenom2Sents.p_id
                            INNER JOIN Sentences
                                ON Sentences.s_id = Phenom2Sents.s_id
                            WHERE Phenomena.p_string = '{}'
                            """.format(phenom_string))
            for row in cursor.fetchall():
                s_string, s_id = row
                temp_row = '{} | {}\n'.format(s_id, s_string ) 
                temp = temp + temp_row
            return temp
    
    ## Return Phenomena that describe a certain Sentence
    def FindPhenomForSent(self, sent_string):
        temp = '-------------------------------------\n'
        temp = temp + 'Phenomena that describe " {} " \n'.format(sent_string)
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select Phenomena.p_string, Phenomena.p_id from Phenom2Sents 
                            INNER JOIN Phenomena
                                ON Phenomena.p_id = Phenom2Sents.p_id
                            INNER JOIN Sentences
                                ON Sentences.s_id = Phenom2Sents.s_id
                            WHERE Sentences.s_string = '{}'
                            """.format(sent_string))
            for row in cursor.fetchall():
                p_string, p_id = row
                temp_row = '{} | {}\n'.format(p_id, p_string ) 
                temp = temp + temp_row
            return temp

    ## Return the sentences that have multiple readings
    def FindSentReadings(self):
        temp = '-------------------------------------\n'
        temp = temp + 'Sentences with Multiple Readings\n'
        with sqlite3.connect(self.db_filename) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                            select Sentences.s_string, Sentences.s_id from Runs
                            INNER JOIN TMRs
                                ON Runs.tmr_id = TMRs.tmr_id
                            INNER JOIN Sentences
                                ON Sentences.s_id = TMRs.s_id
                            WHERE Runs.num_runs > 0
                            """)
            for row in cursor.fetchall():
                s_string, s_id = row
                temp_row = '{} | {}\n'.format(s_id, s_string ) 
                temp = temp + temp_row
            return temp