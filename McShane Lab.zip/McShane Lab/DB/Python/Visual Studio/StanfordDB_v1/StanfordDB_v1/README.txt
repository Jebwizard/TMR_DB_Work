Stanford Database Version 0.02
	Implemented with sqlite3 Python Package

Readme Updated Septemder 12, 2016 by Joel Bassett

---Description:
This is a Python GUI that allowes the user to input and store TMR components, 
	Analyzer runs, Sentences, and Phenomena.
This creates a database file in the same directory as the python code.

---How to use:
The Following files need to be in the same directory:
	Stanford_Schema.sql
	SQLFunc.py
	DBConnection.py
	StandfordDB_v1.py
Open a Python enviroment and run StandfordDB_v1.py.
You will be prompted to input the name of the database that you want to access.
(DO NOT add file extentions) 

If you provide a name that does not exist, then a database of that name is generated. 
	This might take up to a minute.
If you provide a name that does exist or after a new database is generated,
	you will be presented with the GUI.

Once at the GUI, you can use the tabs to view your options to view data, add data,
	or find relationships in the data.

"See Data" Tab:
The buttons each produce a small window that has a printout of the corresponding table.
	"Sentence/Phenomena Table", "Runs Table", and "Components Table" do not print out the table, but instead produces a view. This enables better ease of use. The actual tables store references to other tables and not the actual values.
	
"Add" Tab:
This tab has several sub tabs that indicate what can be added to the Database by the user.
These fields ARE case sensitive. test does not equal Test.
In the "Component" tab, you can leave any of the fields blank, EXCEPT "TMR ID"
In the "Relashionship" tab, you provide the sentence. If you provide a sentence that does not exist in the database, it will be added. You select the phenomena that is to be paired to the sentnece from a dropdown menu. The options provided are determined at teh start of the program. If you add additonal pheonema options, they will not show up here. You will have to restart the program.

Unless stated otherwise, all fields are required.
After all the fields in a tab are filled out, click the "submit" button to add the data. You will then be shown the approprate table that will include the new data.

"Find" Tab:
This contains four questions that can be asked of the database. For the first 3, supply the appropriate information. This IS case sensitive. This will not add new data.

After clicking "Submit", the program produces the approrite reponse table.


---Database Schema:
Table:
	Row

Sentences:			Phenomena:
	s_string			p_string
	s_id				p_id

Phenom2Sents:			Users:
	p_id				u_id
	s_id				u_name
	
TMRs:				Runs:
	tmr_id				r_id
	tmr_string			tmr_id
	s_id				time_stamp
					u_id
Components:
	c_id
	tmr_id
	sco_id
	to_id
	con_id
	sen_id
	att_to_id
	memty_id
	c_string




---Notes:




---Issues:




---What to improve next: