import pypyodbc

try:
    myConnection = pypyodbc.connect('Driver={SQL Server},'
                                    'Server=localhost;'
                                    'Database=QuizDB'
                                    'uid=testUser;pwd=P@ssw0rd')
    print('woohoo give me the cookie')
    myConnection.close()
except:
    print('bummer no cookie')
