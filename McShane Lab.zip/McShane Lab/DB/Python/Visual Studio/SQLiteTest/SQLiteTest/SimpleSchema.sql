﻿CREATE TABLE Sentences(
	s_string TEXT UNIQUE,
	s_id INTEGER NOT NULL PRIMARY KEY
);
CREATE TABLE Phenomena(
	p_string TEXT UNIQUE,
	p_id INTEGER NOT NULL PRIMARY KEY
);
CREATE TABLE Phenom2Sents(
	p_id INTEGER NOT NULL references Phenomena(p_id),
	s_id INTEGER NOT NULL references Sentences(s_id),
	UNIQUE (p_id,s_id)
);