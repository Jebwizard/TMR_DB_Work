#import os
#import sys
#import sqlite3
import DBConnection

DB = DBConnection.DBConnection('test.db','Stanford_Schema.sql')

TMR_STRING_1 = """ Hello I'll be as crazy with these 'apostrapheies' as I can."""

tmr_row = DB.addTMR(TMR_STRING_1, 'Sentence 1')

COMP_STRING_1 = "This is a Test! Didn't it work? It had better!"
COMP_STRING_2 = "2nd test string"

DB.addComponent(tmr_row,COMP_STRING_1)
DB.addComponent(tmr_row,COMP_STRING_2, scope = 'near', token = 'I')
DB.addComponent(tmr_row,COMP_STRING_2, scope = 'near', token = 'I')

DB.SentencesTable()
DB.TMRsTable()

DB.ComponentsTable()

DB.ComponentsView()