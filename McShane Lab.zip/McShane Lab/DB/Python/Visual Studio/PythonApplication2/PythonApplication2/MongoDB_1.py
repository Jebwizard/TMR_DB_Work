#from pymongo import MongoClient
import collections

#client = MongoClient()

#DATA = { 1:"one", 2:["two"], 3:{1:"threeOne", 'a':"threeTwo"}}
DATA = {'results': [{'TMR': {'HUMAN-1': {'GENDER': 'MALE', 'from-sense': 'HE-N1', 'token': 'He', 'concept': 'HUMAN', 'is-in-subtree': 'OBJECT', 'sent-word-ind': (0, 0), 'CONSCIOUS': 'YES'}}, 'words': {0: 'HE-N1', 2: 'CONSCIOUS-ADJ1'}, 'concept_counts': {'HUMAN': {'word-info': [[0, 'top']], 'count': 1}}}, {'TMR': {'ANIMAL-1': {'GENDER': 'MALE', 'from-sense': 'HE-N2', 'token': 'He', 'concept': 'ANIMAL', 'is-in-subtree': 'OBJECT', 'sent-word-ind': (0, 0), 'CONSCIOUS': 'YES'}}, 'words': {0: 'HE-N2', 2: 'CONSCIOUS-ADJ1'}, 'concept_counts': {'ANIMAL': {'word-info': [[0, 'top']], 'count': 1}}}], 'timestamp': '2016-Jul-21 19:57:04', 'sentence': 'He is conscious.', 'sent-num': 0}

def convert_keys_to_string(dictionary):
    # Recursively converts dictionary keys to strings.
    if isinstance(dictionary, dict):
        return dict((str(k), convert_keys_to_string(v)) 
        for k, v in dictionary.items())
    elif isinstance(dictionary, list):
        return [ convert_keys_to_string(x) for x in dictionary ]
    else:
        return dictionary

print(DATA)
print(convert_keys_to_string(DATA))