﻿CREATE TABLE Sentences (
	s_id INTEGER IDENTITY PRIMARY KEY NOT NULL,
	s_string TEXT NOT NULL UNIQUE
	)

CREATE TABLE Phenomena (
	p_id INTEGER IDENTITY PRIMARY KEY NOT NULL,
	p_string TEXT NOT NULL UNIQUE
	)

CREATE TABLE Phenom2Sents (
	ps_id INTEGER IDENTITY PRIMARY KEY NOT NULL,
	p_id INTEGER FOREIGN KEY REFERENCES Phenomena(p_id),
	s_id INTEGER FOREIGN KEY REFERENCES Sentences(s_id)
	)

CREATE TABLE Users(
	u_id INTEGER IDENTITY PRIMARY KEY,
	u_name TEXT NOT NULL UNIQUE
	)

CREATE TABLE TMRs(
	tmr_id INTEGER IDENTITY PRIMARY KEY NOT NULL,
	tmr_string TEXT NOT NULL,
	s_id INTEGER FOREIGN KEY REFERENCES Sentences(s_id)
	)

CREATE TABLE Runs(
	r_id INTEGER IDENTITY PRIMARY KEY NOT NULL,
	tmr_id INTEGER FOREIGN KEY REFERENCES TMRs(tmr_id),
	time_stamp REAL UNIQUE,
	u_id INTEGER
	)

CREATE TABLE Tokens (
	to_id INTEGER IDENTITY PRIMARY KEY NOT NULL,
	to_string TEXT NOT NULL UNIQUE
	)

CREATE TABLE Senses (
	sen_id INTEGER IDENTITY PRIMARY KEY NOT NULL,
	sen_string TEXT NOT NULL UNIQUE
	)

CREATE TABLE Scopes (
	scope_id INTEGER IDENTITY PRIMARY KEY NOT NULL,
	scope_string TEXT NOT NULL UNIQUE
	)

CREATE TABLE Member_Types (
	memty_id INTEGER IDENTITY PRIMARY KEY NOT NULL,
	memty_string TEXT NOT NULL UNIQUE
	)

CREATE TABLE Concepts (
	con_id INTEGER IDENTITY PRIMARY KEY NOT NULL,
	con_string TEXT NOT NULL UNIQUE
	)

CREATE TABLE Attributed_Tos (
	att_to_id INTEGER IDENTITY PRIMARY KEY NOT NULL,
	att_to_string TEXT NOT NULL UNIQUE
	)

CREATE TABLE Components(
	c_id INTEGER IDENTITY PRIMARY KEY NOT NULL,
	tmr_id INTEGER FOREIGN KEY REFERENCES TMRs(tmr_id),
	scope_id INTEGER FOREIGN KEY REFERENCES Scopes(scope_id),
	to_id INTEGER FOREIGN KEY REFERENCES Tokens(to_id),
	con_id INTEGER FOREIGN KEY REFERENCES Concepts(con_id),
	sen_id INTEGER FOREIGN KEY REFERENCES Senses(sen_id),
	att_to_id INTEGER FOREIGN KEY REFERENCES Attributed_Tos(att_to_id),
	memty_id INTEGER FOREIGN KEY REFERENCES Member_Types(memty_id),
	c_string TEXT NOT NULL							
	)

--CREATE VIEW v_SentPhenom
--AS
--SELECT Sentences.s_string,  Phenomena.p_string
--FROM Phenom2Sents
--	INNER JOIN Sentences
--		ON Sentences.s_id = Phenom2Sents.s_id
--	INNER JOIN Phenomena
--		ON Phenomena.p_id = Phenom2Sents.p_id

--CREATE VIEW v_Components
--AS
--SELECT Components.c_id, Components.tmr_id, Scopes.scope_string,
--		Tokens.to_string, Concepts.con_string, Senses.sen_string,
--		Attributed_Tos.att_to_string, Member_Types.memty_string
--FROM Components
--	INNER JOIN Scopes
--		ON Components.scope_id = Scopes.scope_id
--	INNER JOIN Tokens
--		ON Components.to_id = Tokens.to_id
--	INNER JOIN Concepts
--		ON Components.con_id = Concepts.con_id
--	INNER JOIN Senses
--		ON Components.sen_id = Senses.sen_id
--	INNER JOIN Attributed_Tos
--		ON Components.att_to_id = Attributed_Tos.att_to_id
--	INNER JOIN Member_Types
--		ON Components.memty_id = Member_Types.memty_id