from tkinter import *
from tkinter import ttk

root = Tk()
root.title('Notebook test')
mainframe = ttk.Frame(root, padding="3 3 12 12")
mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
mainframe.columnconfigure(0, weight=1)
mainframe.rowconfigure(0, weight=1)

n = ttk.Notebook(mainframe)
n.grid(column=0, row=0)

f1 = ttk.Frame(n)
f2 = ttk.Frame(n)
f3 = ttk.Frame(n)
n.add(f1, text='Connect')
n.add(f2, text='Add')
n.add(f3, text='Find')

label = ttk.Label(f2, text='Add the following element :').grid(column = 0, row = 0)

n_add = ttk.Notebook(f2)
n_add.grid(column=0, row=1)

f_add1 = ttk.Frame(n_add)
f_add2 = ttk.Frame(n_add)
f_add3 = ttk.Frame(n_add)
n_add.add(f_add1, text='Sentence')
n_add.add(f_add2, text='Phenomena')
n_add.add(f_add3, text='TMR run')




root.mainloop()
