# Contains the methods to interface with SQL and SQLserver

from tkinter import *
from tkinter import ttk
#import tk_MessageBox
from DBConnection import DBConnection



class SQLFunc:
    DataBase = None
    def __init__(self):
        print("What Database do you want to use?")
        #print("You can change this later.")
        input_var = input(" : ")
        print ("you entered " + input_var) 
        DataBase = DBConnection.DBConnection(input_var,'Stanford_Schema.sql')
        pass

    def connect_button(*args):
        error_not_coded()
        print("Not coded yet")
    
    def error_not_coded():
        root = Tk()
        root.title('ERROR')
        mainframe = ttk.Frame(root, padding="6 6 24 24")
        mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
        mainframe.columnconfigure(0, weight=1)
        mainframe.rowconfigure(0, weight=1)
        label = ttk.Label(mainframe, text='This is not coded yet')
        label.grid(column=0, row=0, sticky=(N, W, E, S))
        #tk_MessageBox.showerror('Error','This is not coded yet')

    def getPhenomOptions():
        return ['', 'personal pronoun','demonstrative pronoun',
                'BRE-NP','NP-def','NP-indef','VP ellipsis','I',
                'you','he','she','it','they','we','intransitive',
                'transitive','ditransitive','xcomp','comp','plus-PP',
                'plus-PP-opt','relative clause','passive','question',
                'command','dialog fragment','non-dialog fragment',
                'modality','set','aspect','indirect speech act','implicature']
