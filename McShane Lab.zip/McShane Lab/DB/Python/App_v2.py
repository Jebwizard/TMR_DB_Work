# This is the GUI library
from tkinter import *
from tkinter import ttk
# This contains the logic to "talk" with SQL
import SQLFunc

# Create the main window and the main frame
root = Tk()
root.title('Database Access')
# to add a custom icon:
# root.iconbitmap( pathname )
mainframe = ttk.Frame(root, padding="3 3 12 12")
mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
mainframe.columnconfigure(0, weight=1)
mainframe.rowconfigure(0, weight=1)


# Create the highest level Tabs to split apart the main types of operations
n = ttk.Notebook(mainframe)
n.grid(column=0, row=0, sticky=(N, W, E, S))

# Create and add the tabs of the highest types of operations
f1 = ttk.Frame(n)
f2 = ttk.Frame(n)
f3 = ttk.Frame(n)
n.add(f1, text='Connect')
n.add(f2, text='Add')
n.add(f3, text='Find')

# -----------------------------------------------------------------------
# Widgets for the Connect Tab

connect_uid = StringVar()
l_connect_uid = ttk.Label(f1, text='Username : ').grid(column=0, row=0)
e_connect_uid = ttk.Entry(f1, textvariable=connect_uid, width = 50).grid(column=1,row=0)

connect_pw = StringVar()
l_connect_pw = ttk.Label(f1, text='Password : ').grid(column=0, row=2)
e_connect_pw = ttk.Entry(f1, textvariable=connect_pw, width = 50).grid(column=1,row=2)

b_connect = ttk.Button(f1, text='Submit', command=SQLFunc.connect_button).grid(column=1,row=3)


# ------------------------------------------------------------------------
# Widgets for the Add Tab

label = ttk.Label(f2, text='Add the following element :').grid(column = 0, row = 0)

# Sub notebook to differentiate between the elements that are to be added
n_add = ttk.Notebook(f2)
n_add.grid(column=0, row=1, sticky=(N, W, E, S))

# Create and add the tabs of the types of elements that can be added
f_add1 = ttk.Frame(n_add)
f_add2 = ttk.Frame(n_add)
f_add3 = ttk.Frame(n_add)
f_add4 = ttk.Frame(n_add)
f_add5 = ttk.Frame(n_add)
#f_add6 = ttk.Frame(n_add)

n_add.add(f_add5, text='Component')
n_add.add(f_add2, text='Phenomenon')
n_add.add(f_add4, text='Relationship')
n_add.add(f_add1, text='Sentence')
n_add.add(f_add3, text='TMR run')
#n_add.add(f_add6, text='User')

# Widgets for the Add->Component tab
# frame = f_add5          
l_component_info = ttk.Label(f_add5,
                             text='Leave blank if the component does not have a certain field').grid(
                                                                                                column=0,
                                                                                                row=0,
                                                                                                columnspan=2)
v_tmr = StringVar()
l_tmr = ttk.Label(f_add5, text='TMR ID : ').grid(column=0, row=1)
e_tmr = ttk.Entry(f_add5, textvariable=v_tmr, width = 100).grid(
                                                                column=1, row=1)
l_scope = ttk.Label(f_add5, text='SCOPE : ').grid(column=0, row=2)
v_scope = StringVar()
e_scope = ttk.Entry(f_add5, textvariable=v_scope, width = 100).grid(
                                                                column=1, row=2)
l_token = ttk.Label(f_add5, text='TOKEN : ').grid(column=0, row=3)
v_token = StringVar()
e_token = ttk.Entry(f_add5, textvariable=v_token, width = 100).grid(
                                                                column=1, row=3)
l_concept = ttk.Label(f_add5, text='CONCEPT : ').grid(column=0, row=4)
v_concept = StringVar()
e_concept = ttk.Entry(f_add5, textvariable=v_concept, width = 100).grid(
                                                                column=1, row=4)
l_member_type = ttk.Label(f_add5, text='MEMBER-TYPE : ').grid(column=0, row=5)
v_member_type = StringVar()
e_member_type = ttk.Entry(f_add5, textvariable=v_member_type, width = 100).grid(
                                                                column=1, row=5)
l_senses = ttk.Label(f_add5, text='FROM-SENSE : ').grid(column=0, row=6)
v_senses = StringVar()
e_senses = ttk.Entry(f_add5, textvariable=v_senses, width = 100).grid(
                                                                column=1, row=6)
l_attributed = ttk.Label(f_add5, text='ATTRIBUTED-TO : ').grid(column=0, row=7)
v_attributed = StringVar()
e_attributed = ttk.Entry(f_add5, textvariable=v_attributed, width = 100).grid(
                                                                column=1, row=7)
b_add_component = ttk.Button(f_add5, text='Submit', command=SQLFunc.connect_button).grid(
                                                                                column=1,
                                                                                row=8)


# Widgets for the Add->Sentence tab
l_new_sent = ttk.Label(f_add1, text='Sentence :').grid(column=0, row = 0)
new_sentence = StringVar()
e_add_sentence = ttk.Entry(f_add1,textvariable=new_sentence, width = 100).grid(
                                                            column=1,
                                                            row=0,
                                                            sticky = (E,W))
b_add_sent = ttk.Button(f_add1, text='Submit', command=SQLFunc.connect_button).grid(
                                                                                column=1,
                                                                                row=1)

# Widgets for the Add->Phenomena tab
l_new_phenom = ttk.Label(f_add2, text='Phenomenon :').grid(column=0, row = 0)
new_phenomena = StringVar()
e_add_phenomena = ttk.Entry(f_add2,textvariable=new_phenomena, width = 100).grid(
                                                            column=1,
                                                            row=0,
                                                            sticky = (E,W))
e_add_phenom = ttk.Button(f_add2, text='Submit', command=SQLFunc.connect_button).grid(
                                                                            column=1,
                                                                            row=1)
# Widgets for the Add->TMR Run tab

# Labels for what to enter where
l_sentence = ttk.Label(f_add3, text='Senetnece :').grid(column = 0, row = 0)
l_name = ttk.Label(f_add3, text='Name :').grid(column = 0, row = 1)
l_TMR = ttk.Label(f_add3, text='TMR :').grid(column = 0, row = 2)
l_number = ttk.Label(f_add3, text='Number of Runs :').grid(column = 0, row = 3)

# Variables to capture what is inputed
tmr_sentence = StringVar()
tmr_name = StringVar()
tmr_text = StringVar()
# use this code to access the text of the Text wiget: .get('1.0', 'end-1c')
tmr_num = IntVar()

# The means to capture the input, including entrys, text, and a scrollbar
e_tmr_sent = ttk.Entry(f_add3, textvariable=tmr_sentence, width = 100).grid(column=1,row=0)
e_tmr_name = ttk.Entry(f_add3, textvariable=tmr_name, width = 100).grid(column=1,row=1)
e_tmr_tmr = Text(f_add3, height=10, width=60 )
e_tmr_tmr.grid(column=1,row=2)
#not working
s = Scrollbar(f_add3, orient=VERTICAL)
e_tmr_tmr.configure(yscrollcommand=s.set)
s.configure(command=e_tmr_tmr.yview)

e_num = ttk.Entry(f_add3, textvariable=tmr_num, width = 10).grid(column=1,row=3)

# Button to submit responces
b_add_run = ttk.Button(f_add3, text='Submit', command=SQLFunc.connect_button).grid(
                                                                                column=1,
                                                                                row=4)

# Widegets for the Add-> Relationships tab
# f_add4

phenom_options = SQLFunc.getPhenomOptions()

l_top = ttk.Label(f_add4, text='Connect a Sentnece to a Phenomenon').grid(column=0,
                                                                            row=0)
relat_sent = StringVar()
relat_phenom_1 = StringVar()
relat_phenom_1.set(phenom_options[1])

l_relate_sent = ttk.Label(f_add4, text='Sentence:').grid(column=0,row=1)
e_relate_sent = ttk.Entry(f_add4, textvariable=relat_sent, width = 100).grid(
                                                                column=1,
                                                                row=1)
l_relate_phenom = ttk.Label(f_add4, text='Phenomena:').grid(column=0,row=2)
#e_relate_phenom = ttk.Entry(f_add4, textvariable=relat_phenom_1, width = 100).grid(
#                                                                column=1,
#                                                                row=2)
d_phenom_dropdown_1 = ttk.OptionMenu(f_add4, relat_phenom_1, *phenom_options).grid(
                                                                    column=1,
                                                                    row=2)

b_sent_relat = ttk.Button(f_add4, text='Submit', command=SQLFunc.connect_button).grid(
                                                                            column = 1,
                                                                            row = 3)



# not working
# seperator = ttk.Separator(f_add4, orient = HORIZONTAL).grid(row=4)


label_bottom = ttk.Label(f_add4, text='Connect a TMR to a Phenomenon').grid(column=0,
                                                                          row=5)
relat_tmr = StringVar()
relat_phenom_2 = StringVar()
relat_phenom_2.set(phenom_options[1])

l_relate_tmr = ttk.Label(f_add4, text='TMR ID:').grid(column=0,row=6)
e_relate_tmr= ttk.Entry(f_add4, textvariable=relat_tmr, width = 100).grid(
                                                                column=1,
                                                                row=6)
l_relate_phenom = ttk.Label(f_add4, text='Phenomenon:').grid(column=0,row=7)
#e_relate_phenom = ttk.Entry(f_add4, textvariable=relat_phenom_2, width = 100).grid(
#                                                                column=1,
#                                                                row=7)
d_phenom_dropdown_2 = ttk.OptionMenu(f_add4, relat_phenom_2, *phenom_options).grid(
                                                                    column=1,
                                                                    row=7)


b_tmr_relat = ttk.Button(f_add4, text='Submit', command=SQLFunc.connect_button).grid(
                                                                            column = 1,
                                                                            row = 8)

# Already part of Add-> TMR run
# Widgets for Add-> User Tab
#l_user = ttk.Label(f_add6, text='User Name : ').grid(column=0, row=0)
#v_user = StringVar()
#e_user = ttk.Entry(f_add6, textvariable=v_attributed, width = 100).grid(
#                                                                column=1, row=0)
#b_add_component = ttk.Button(f_add6, text='Submit', command=SQLFunc.connect_button).grid(
#                                                                                column=1,
#                                                                                row=1)


# --------------------------------------------------------------------------------
# Widgets for the Find tab
# frame : f3

find_1 = StringVar()
l_find_1 = ttk.Label(f3,text='What TMRs describe the following sentence?').grid(
                                                                            column=0,
                                                                            row=0)
e_find_1 = ttk.Entry(f3, textvariable = find_1, width = 100).grid(
                                                                column=0,
                                                                row=1)
b_find_1 = ttk.Button(f3, text='Submit', command=SQLFunc.connect_button).grid(
                                                                        column=0,
                                                                        row=2)

find_2 = StringVar()
l_find_2 = ttk.Label(f3,text='What sentences conatin the following phenomenon?').grid(
                                                                            column=0,
                                                                            row=3)
e_find_2 = ttk.Entry(f3, textvariable = find_2, width = 100).grid(
                                                                column=0,
                                                                row=4)
b_find_2 = ttk.Button(f3, text='Submit', command=SQLFunc.connect_button).grid(
                                                                        column=0,
                                                                        row=5)

find_3 = StringVar()
l_find_3 = ttk.Label(f3,text='What phenomena are in the following sentence?').grid(
                                                                            column=0,
                                                                            row=6)
e_find_3 = ttk.Entry(f3, textvariable = find_3, width = 100).grid(
                                                                column=0,
                                                                row=7)
b_find_3 = ttk.Button(f3, text='Submit', command=SQLFunc.connect_button).grid(
                                                                        column=0,
                                                                        row=8)

l_find_4 = ttk.Label(f3,text='What sentences have mulitple readings?').grid(
                                                                            column=0,
                                                                            row=9)
b_find_4 = ttk.Button(f3, text='Submit', command=SQLFunc.connect_button).grid(
                                                                        column=0,
                                                                        row=10)


# This catches the closing to the main window to ensure
# that the connection to the server is cut off

def on_closing():
    print("I am closing!")
    #if connected is True:
    #    connection.close()
    root.destroy()

root.protocol("WM_DELETE_WINDOW",on_closing)

# Command to run the application in a loop till terminated by the  user
root.mainloop()
