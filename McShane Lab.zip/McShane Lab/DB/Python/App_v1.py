# C:\Users\bassej4\Documents\McShane Lab\DB\Python
# Started - 6/18/2016
# Coded by Joel Bassett

import tkinter
import SQLFunc

class app_tk(tkinter.Tk):
    def __init__(self,parent):
        tkinter.Tk.__init__(self,parent)
        self.parent = parent
        self.initialize()

    def initialize(self):
        self.grid()

        self.button_connect = tkinter.Button(self,text=u"Connect",
                                    command=self.OnButtonClick)
        self.button_connect.grid(column=0,row=0,sticky='EW')

        self.button_add = tkinter.Button(self,text=u"Add",
                                    command=self.OnButtonClick)
        self.button_add.grid(column=1,row=0,sticky='EW')

        self.button_find = tkinter.Button(self,text=u"Find",
                                    command=self.OnButtonClick)
        self.button_find.grid(column=2,row=0,sticky='EW')

        self.frame_blank = tkinter.Frame(height=30)
        self.frame_blank.grid(column=0,row=1,columnspan=3)

        self.labelVariable = tkinter.StringVar()
        self.label = tkinter.Label(self,textvariable=self.labelVariable,anchor='w')
        self.label.grid(column=0,row=2,columnspan=3,sticky='EW')
        self.labelVariable.set(u"Add a :")

        self.elementType = tkinter.StringVar()
        self.elementType.set('sentence')
        self.radio_sentence = tkinter.Radiobutton(self, text='Sentence',
                                                      variable = self.elementType,
                                                      value='sentence')
        self.radio_sentence.grid(column=0,row=3)
        self.radio_phenomena= tkinter.Radiobutton(self, text='Phenomena',
                                                    variable = self.elementType,
                                                    value='phenomena')
        self.radio_phenomena.grid(column=1,row=3)
        self.radio_tmr = tkinter.Radiobutton(self, text='TMR Run',
                                                    variable = self.elementType,
                                                    value='run')
        self.radio_tmr.grid(column=2,row=3)

        self.frame_result = tkinter.Frame(self)
        self.frame_result.grid(column=0,row=6,columnspan=3)

        self.entryVariable = tkinter.StringVar()
        self.entry = tkinter.Entry(self,textvariable=self.entryVariable)

        radio_condition=self.elementType.get()
        if radio_condition == 'sentence':
            self.entry.grid(column=0,row=4,columnspan=3,sticky='EW')
            self.entry.bind("<Return>", self.OnPressEnter)
            self.entryVariable.set(u"Enter Sentence Here.")
            
        elif radio_condition == 'phenomena':
            self.entry.grid(column=0,row=4,columnspan=3,sticky='EW')
            self.entry.bind("<Return>", self.OnPressEnter)
            self.entryVariable.set(u"Enter Phenomena Here.")
            
        elif radio_condition == 'run':
            pass
        
        else:
            pass
            #self.entry.grid(column=0,row=4,columnspan=3,sticky='EW')
            #self.entry.bind("<Return>", self.OnPressEnter)
            #self.entryVariable.set(u"Enter text here.")

        self.button_submit = tkinter.Button(self,text=u"submit",
                                    command=self.OnButtonClick)
        self.button_submit.grid(column=2,row=5,sticky='EW')

        self.frame_result = tkinter.Frame(height=100)
        self.frame_result.grid(column=0,row=6,columnspan=3)

        self.rowconfigure(3,pad=10)       
        self.resizable(False,False)
        self.update()
        self.geometry(self.geometry())
        self.entry.focus_set()
        self.entry.selection_range(0, tkinter.END)

    def OnButtonClick(self):
        pass
        #self.labelVariable.set( self.entryVariable.get()+" (You clicked the button !)")
        #self.entry.focus_set()
        #self.entry.selection_range(0, tkinter.END)
        
    def OnPressEnter(self,event):
        pass
        #self.labelVariable.set( self.entryVariable.get()+" (You pressed ENTER)" )
        #self.entry.focus_set()
        #self.entry.selection_range(0, tkinter.END)        
        

if __name__ == "__main__":
    app = app_tk(None)
    app.title('Database Access')
    app.MainLoop()

