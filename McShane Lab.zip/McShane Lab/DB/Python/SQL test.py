import pypyodbc
import datetime


try:
    connection = pypyodbc.connect('Drive={SQL Server};'
                              'Server=localhost'
                              'Database=testdb;'
                              'uid=sa;pwd=P@ssw0rd')

    print('I think we connected')
    connection.close()
    print('I think we diconnected')
except:
    print('This failed...')



