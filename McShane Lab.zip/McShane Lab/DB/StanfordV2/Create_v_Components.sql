CREATE VIEW v_Components
AS
SELECT Components.c_id, Components.tmr_id, Scopes.scope_string,
		Tokens.to_string, Concepts.con_string, Senses.sen_string,
		Attributed_Tos.att_to_string, Member_Types.memty_string
FROM Components
	INNER JOIN Scopes
		ON Components.scope_id = Scopes.scope_id
	INNER JOIN Tokens
		ON Components.to_id = Tokens.to_id
	INNER JOIN Concepts
		ON Components.con_id = Concepts.con_id
	INNER JOIN Senses
		ON Components.sen_id = Senses.sen_id
	INNER JOIN Attributed_Tos
		ON Components.att_to_id = Attributed_Tos.att_to_id
	INNER JOIN Member_Types
		ON Components.memty_id = Member_Types.memty_id