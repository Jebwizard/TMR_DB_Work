CREATE VIEW v_SentPhenom
AS
SELECT Sentences.s_string,  Phenomena.p_string
FROM Phenom2Sents
	INNER JOIN Sentences
		ON Sentences.s_id = Phenom2Sents.s_id
	INNER JOIN Phenomena
		ON Phenomena.p_id = Phenom2Sents.p_id