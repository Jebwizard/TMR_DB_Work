CREATE TABLE Components(
	c_id INT IDENTITY PRIMARY KEY NOT NULL,
	tmr_id INT FOREIGN KEY REFERENCES TMRs(tmr_id),
	scope_id INT FOREIGN KEY REFERENCES Scopes(scope_id),
	to_id INT FOREIGN KEY REFERENCES Tokens(to_id),
	con_id INT FOREIGN KEY REFERENCES Concepts(con_id),
	sen_id INT FOREIGN KEY REFERENCES Senses(sen_id),
	att_to_id INT FOREIGN KEY REFERENCES Attributed_Tos(att_to_id),
	memty_id INT FOREIGN KEY REFERENCES Member_Types(memty_id),
	c_string TEXT NOT NULL							
	)