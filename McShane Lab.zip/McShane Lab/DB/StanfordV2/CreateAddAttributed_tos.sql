CREATE PROCEDURE AddAttributed_tos ( @i_att_tos_string VARCHAR(900) )
AS
BEGIN
INSERT INTO Attributed_Tos
	SELECT @i_att_tos_string
	WHERE NOT EXISTS (SELECT att_to_id
						FROM Attributed_Tos
						WHERE att_to_string = @i_att_tos_string)
END