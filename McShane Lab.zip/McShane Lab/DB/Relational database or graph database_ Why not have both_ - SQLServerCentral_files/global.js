function ssc_showPostsSinceLastVisit() {
	// Make a form we can post
	// (don't use the existing one as it contains unhelpful VIEWSTATE info and its name varies)
	var form = document.createElement("FORM");
	form.action = "/Forums/Default.aspx";
	form.method = "POST";
	form.style.display = "none";
	document.body.appendChild(form);
	var target = form.appendChild(document.createElement("INPUT"));
	target.name = "__EVENTTARGET";
	target.value = "smRecentPosts";
	var argument = form.appendChild(document.createElement("INPUT"));
	argument.name = "__EVENTARGUMENT";
	argument.value = "butViewPostsSinceLastVisit";
	form.submit();
}

/**
 * BEGIN
 * Logic for posting email address from text fragments to the register page
 */
function signupEmail(email) {
    var path = 'https://' + window.location.hostname + '/Register?ReturnURL=' + encodeURIComponent(location.pathname + location.search + location.hash);

    // If nothing was typed into the email address field, 
    // we don't want to submit "undefined" as the email address..
    if (typeof email == "undefined") {
        email = "";
    }

    post(path, {
        signupFragmentRegisterEmail: email
    });
}

function post(path, params, method) {
    method = method || "post"; // Set method to post by default if not specified.

    // The rest of this code assumes you are not using a library.
    // It can be made less wordy if you use one.
    var form = document.createElement("form");
    form.setAttribute("method", method);
    form.setAttribute("action", path);

    for(var key in params) {
        if(params.hasOwnProperty(key)) {
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", key);
            hiddenField.setAttribute("value", params[key]);

            form.appendChild(hiddenField);
        }
    }

    document.body.appendChild(form);
    form.submit();
}

$(function() {
    $('input.signup-email-field').keydown(function(event) {
        if (event.keyCode == 13) { // Return
            signupEmail(this.value);
        }
    });

    $('.signup-email-button').click(function (event) {
        // getting only the nearest email field since there might be more than one on the page
        var nearestEmailInput = $(this)
            .closest('.text-fragment-wrapper')
            .find('input.signup-email-field');

        signupEmail(nearestEmailInput.val());
    });
});

/**
 * Logic for corner peel
 */

$(document).ready(function() {
    if (location.pathname === "/") {
        setTimeout(function() {
            $("#corner-peel img").stop().animate({
                width: '120px',
                height: '120px'
            }, 500);

            $("#corner-peel-behind").stop().animate({
                width: '120px',
                height: '120px'
            }, 500, function() {
                setTimeout(function() {
                    $("#corner-peel img").stop().animate({
                        width: '82px',
                        height: '82px'
                    }, 220);
                    $("#corner-peel-behind").stop().animate({
                        width: '80px',
                        height: '80px'
                    }, 200);
                }, 1000);
            });
        }, 1000);
    }

    $("#corner-peel").hover(function() {
        $("#corner-peel img, #corner-peel-behind").stop().animate({
            width: '307px',
            height: '319px'
        }, 500);
    }, function() {
        $("#corner-peel img").stop().animate({
            width: '82px',
            height: '82px'
        }, 220);
        $("#corner-peel-behind").stop().animate({
            width: '80px',
            height: '80px'
        }, 200); //Note this one retracts a bit faster (to prevent glitching in IE)
    });

});