var request = require('request');

var YOUR_PORT = 8080

//var YOUR_TMR = {'test':'TMR'}

/* 1st attempt
var YOUR_TMR = "{'results': [{'TMR': {'HUMAN-1': {'GENDER': 'MALE', 'from-sense': 'HE-N1', 'token': 'He', 'concept': 'HUMAN', 'is-in-subtree': 'OBJECT', 'sent-word-ind': (0, 0), 'CONSCIOUS': 'YES'}}, 'words': {0: 'HE-N1', 2: 'CONSCIOUS-ADJ1'}, 'concept_counts': {'HUMAN': {'word-info': [[0, 'top']], 'count': 1}}}, {'TMR': {'ANIMAL-1': {'GENDER': 'MALE', 'from-sense': 'HE-N2', 'token': 'He', 'concept': 'ANIMAL', 'is-in-subtree': 'OBJECT', 'sent-word-ind': (0, 0), 'CONSCIOUS': 'YES'}}, 'words': {0: 'HE-N2', 2: 'CONSCIOUS-ADJ1'}, 'concept_counts': {'ANIMAL': {'word-info': [[0, 'top']], 'count': 1}}}], 'timestamp': '2016-Jul-21 19:57:04', 'sentence': 'He is conscious.', 'sent-num': 0} " 

//*/

 /* 2nd attempt - Changed OrderedDict to standard python dictionary
var YOUR_TMR = "{'sentence': 'The lion saw a zebra.', 'timestamp': '2016-Jul-22 14:53:31','results': [{'words': {1: 'LION-N1', 2: 'SEE-V1', 4: 'ZEBRA-N1'},'TMR': {'LION-1': {'concept': 'LION', 'token': 'lion', 'sent-word-ind': (0, 1), 'is-in-subtree': 'OBJECT', 'from-sense': 'LION-N1', 'EXPERIENCER-OF': 'VISUAL-EVENT-1'}, 'ZEBRA-1': {'THEME-OF': 'VISUAL-EVENT-1', 'concept': 'ZEBRA', 'token': 'zebra', 'sent-word-ind': (0, 4), 'is-in-subtree': 'OBJECT', 'from-sense': 'ZEBRA-N1'}, 'VISUAL-EVENT-1': {'syn-roles': ['SUBJECT', 'DIRECTOBJECT'], 'concept': 'VISUAL-EVENT', 'TIME': ['<', 'FIND-ANCHOR-TIME'], 'token': 'saw', 'sent-word-ind': (0, 2), 'is-in-subtree': 'EVENT', 'from-sense': 'SEE-V1', 'THEME': {[('VALUE', 'ZEBRA-1')]}, 'EXPERIENCER': {[('VALUE', 'LION-1')]}}},'concept_counts': {'LION': {'count': 1, 'word-info': [[1, 'top']]}, 'VISUAL-EVENT': {'count': 1, 'word-info': [[2, 'top']]}, 'ZEBRA': {'count': 1, 'word-info': [[4, 'top']]}}}],'sent-num': 0}"

//  */

 /* 3rd attempt
var YOUR_TMR = "{'results': [{'TMR': {'HUMAN-1': {'lex-source': 'NER', 'from-sense': 'JOHN-N1', 'is-in-subtree': 'OBJECT', 'concept': 'HUMAN', 'token': 'John', 'HAS-PERSONAL-NAME': 'JOHN', 'sent-word-ind': (0, 0), 'EXPERIENCER-OF': 'SLEEP-1'}, 'SLEEP-1': {'from-sense': 'SLEEP-V1', 'is-in-subtree': 'EVENT', 'concept': 'SLEEP', 'token': 'sleeping', 'TIME': ['<', 'FIND-ANCHOR-TIME'], 'PHASE': 'CONTINUE', 'syn-roles': ['SUBJECT'], 'EXPERIENCER': OrderedDict([('VALUE', 'HUMAN-1')]), 'sent-word-ind': (0, 2)}}, 'words': {0: 'JOHN-N1', 2: 'SLEEP-V1'}, 'concept_counts': {'HUMAN': {'word-info': [[0, 'top']], 'count': 1}, 'SLEEP': {'word-info': [[2, 'top']], 'count': 1}}}], 'timestamp': '2016-Jul-21 19:57:20', 'sentence': 'John was sleeping.', 'sent-num': 0}"

// */


var options = {
  method: 'post',
  body: YOUR_TMR,
  //json: true,
  url: 'http://localhost:' + YOUR_PORT
}

request(options);