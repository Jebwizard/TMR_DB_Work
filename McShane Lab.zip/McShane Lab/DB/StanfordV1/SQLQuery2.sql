SELECT * FROM Sentence;
SELECT * FROM Phenomena;