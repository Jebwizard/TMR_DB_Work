-- What sentences contain a particular phenomina?
EXECUTE SentsWithPhemon 'noun';
