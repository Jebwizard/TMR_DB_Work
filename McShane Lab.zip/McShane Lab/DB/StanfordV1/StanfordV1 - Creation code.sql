CREATE DATABASE StanfordV1;

CREATE TABLE Sentence
(
	sentID INT IDENTITY PRIMARY KEY NOT NULL,
	sentString NTEXT NOT NULL
);

CREATE TABLE Phenomena
(
	phenomID INT IDENTITY PRIMARY KEY NOT NULL,
	phenomText NTEXT NOT NULL
);

CREATE TABLE Sent2Phenom
(
	sentID INT NOT NULL,
	phenomID INT NOT NULL,
	sent2phemonID INT IDENTITY PRIMARY KEY (sentID, phenomID)
);

CREATE TABLE AnalyzerRun
(
	runID INT IDENTITY PRIMARY KEY NOT NULL,
	sentID INT NOT NULL,
	runBy NVARCHAR(30),
	-- I can't use timestamp, it is reserved
	-- I am setting this to unique to force a chonological order of Runs
	timeID DATETIME UNIQUE NOT NULL,
	runResult NTEXT NOT NULL,
	numReadings INT NOT NULL
);
