SELECT * FROM AnalyzerRun;

EXECUTE RunContainsPhenom 11,'personal pronoun';