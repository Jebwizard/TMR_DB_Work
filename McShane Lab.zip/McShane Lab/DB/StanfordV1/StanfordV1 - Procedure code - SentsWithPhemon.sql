USE [StanfordV1]
GO
/****** Object:  StoredProcedure [dbo].[SentsWithPhemon]    Script Date: 6/7/2016 8:09:55 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


ALTER PROCEDURE [dbo].[SentsWithPhemon](@i_phenomena NTEXT)
AS
BEGIN
	SELECT Sentence.sentString 
	FROM Sentence
		JOIN Sent2Phenom
		ON Sentence.sentID = Sent2Phenom.sentID
		JOIN Phenomena
		ON Sent2Phenom.phenomID = Phenomena.phenomID 
		WHERE phenomText LIKE @i_phenomena
END;