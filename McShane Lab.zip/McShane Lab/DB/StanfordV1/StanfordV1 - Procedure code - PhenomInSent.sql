CREATE PROCEDURE PhenomInSent(@i_sentence NTEXT)
AS
BEGIN
	SELECT phenomText AS PhenomsForSentence FROM Phenomena
	Where phenomID IN(
		SELECT phenomID FROM Sent2Phenom
		WHERE sentID IN(
			SELECT sentID FROM Sentence
			WHERE sentString LIKE 'This is the second test string.'
		)
	);
END;