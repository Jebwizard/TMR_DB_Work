-- Fill Sentence table
INSERT INTO Sentence (sentString) VALUES ('This is the second test string.');
INSERT INTO Sentence (sentString) VALUES ('This is the second test string.');
INSERT INTO Sentence (sentString) VALUES ('This is the third test string.');
INSERT INTO Sentence (sentString) VALUES ('This is the fourth test string.');
INSERT INTO Sentence (sentString) VALUES ('John teaches computer science to high school students and he likes them.');
SELECT * FROM Sentence;

-- Fill Phenomena Table
INSERT INTO Phenomena (phenomText) VALUES ('test phenomena');
INSERT INTO Phenomena (phenomText) VALUES ('noun');
INSERT INTO Phenomena (phenomText) VALUES ('verb');
INSERT INTO Phenomena (phenomText) VALUES ('compound sentence');
SELECT * FROM Phenomena;

-- Fill Sent2Phenom Table
INSERT INTO Sent2Phenom (sentID,phenomID) VALUES (1,1);
INSERT INTO Sent2Phenom (sentID,phenomID) VALUES (1,2);
INSERT INTO Sent2Phenom (sentID,phenomID) VALUES (1,3);
INSERT INTO Sent2Phenom (sentID,phenomID) VALUES (2,1);
INSERT INTO Sent2Phenom (sentID,phenomID) VALUES (2,2);
INSERT INTO Sent2Phenom (sentID,phenomID) VALUES (2,3);
INSERT INTO Sent2Phenom (sentID,phenomID) VALUES (3,1);
INSERT INTO Sent2Phenom (sentID,phenomID) VALUES (4,3);
INSERT INTO Sent2Phenom (sentID,phenomID) VALUES (5,1);
INSERT INTO Sent2Phenom (sentID,phenomID) VALUES (5,2);
INSERT INTO Sent2Phenom (sentID,phenomID) VALUES (5,3);
-- Turns out that NTEXT is depreciated. I need to replace it with somehting else....
INSERT INTO Sent2Phenom (sentID,phenomID) VALUES (5, (SELECT phenomID FROM Phenomena WHERE phenomText LIKE 'compound sentence'));

Select * from Sent2Phenom;
-- SELECT sentString,phenomText FROM Sentence,Phenomena;

Insert INTO AnalyzerRun (sentID,runBy,timeID,runResult,numReadings) VALUES 
		(   ( SELECT sentID FROM Sentence WHERE sentString LIKE 'John teaches computer science to high school students and he likes them.'),
			'Joel',
			GETDATE(),
			' GIANT TMR STRUCTURE GOES HERE!!!!!!!!!! ',
			12);
Insert INTO AnalyzerRun (sentID,runBy,timeID,runResult,numReadings) VALUES 
		(   ( SELECT sentID FROM Sentence WHERE sentString LIKE 'This is the third test string.'),
			'Petr',
			GETDATE(),
			' GIANT TMR STRUCTURE GOES HERE!!!!!!!!!! ',
			12); 
Insert INTO AnalyzerRun (sentID,runBy,timeID,runResult,numReadings) VALUES 
		(   ( SELECT sentID FROM Sentence WHERE sentString LIKE 'This is the first test string.'),
			'Sergei',
			GETDATE(),
			' GIANT TMR STRUCTURE GOES HERE!!!!!!!!!! ',
			12); 

SELECT * FROM AnalyzerRun;